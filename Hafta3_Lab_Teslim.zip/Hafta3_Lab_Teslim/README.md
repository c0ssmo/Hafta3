# İleri Python Programlama — Hafta 3 Lab

Bu depo, Hafta 3 PDF'sindeki görevleri modüllere ve testlere ayırır.

## Dosya yapısı

```text
Hafta3_Lab_Teslim/
├── pyproject.toml
├── README.md
├── kapsam.md
├── uzay_oyunu/
│   ├── __init__.py
│   ├── araclar.py
│   ├── galaksi.json
│   ├── kayit.py
│   └── oyun.py
└── tests/
    ├── test_araclar.py
    ├── test_fonksiyonlar.py
    └── test_tuzaklar.py
```

## Kurulum ve test

Python 3.10 veya üzeri ve `uv` kurulu olmalıdır. Proje klasöründe:

```bash
uv sync
uv run pytest
```

Oyunu başlatmak için:

```bash
uv run python -m uzay_oyunu.oyun
```

`travel()` fonksiyonu hedef numaralarını kullanıcıdan alır; `q` ile yolculuk durdurulabilir. Kapsam örneklerinin tahminleri, gerçek sonuçları ve açıklamaları `kapsam.md` içindedir.
