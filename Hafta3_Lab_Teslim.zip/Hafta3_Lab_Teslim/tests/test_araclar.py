"""Closure, lambda ile sıralama ve dekoratör testleri."""

from uzay_oyunu.araclar import en_bagli_gezegenler, hamle_sayaci, sure_olc


def test_hamle_sayaci_artarak_ilerler() -> None:
    say = hamle_sayaci()
    assert (say(), say(), say()) == (1, 2, 3)


def test_gezegenler_baglanti_sayisi_ve_alfabetik_siraya_gore_dizilir() -> None:
    galaksi = {
        "gezegenler": ["dünya", "centauri", "sirius", "orion", "kara_delik"],
        "baglantilar": {
            "dünya": ["centauri", "sirius"],
            "centauri": ["dünya", "orion"],
            "sirius": ["dünya", "kara_delik"],
            "orion": ["centauri", "kara_delik"],
            "kara_delik": ["sirius", "orion"],
        },
    }
    assert en_bagli_gezegenler(galaksi) == ["centauri", "dünya", "kara_delik", "orion", "sirius"]


def test_sure_olc_sonucu_ve_argumanlari_korur(capsys) -> None:
    def carp(toplam: int, *, katsayi: int = 2) -> int:
        return toplam * katsayi

    olculu = sure_olc(carp)
    assert olculu(5, katsayi=3) == 15
    assert "çalışma süresi" in capsys.readouterr().out
