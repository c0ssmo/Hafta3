"""Mutable varsayılan argüman tuzağı ve kapsam örnekleri."""

from collections.abc import Callable


def test_mutable_default_list_is_shared_between_calls() -> None:
    """Hatalı sürümün aynı listeyi çağrılar arasında paylaştığını gösterir."""
    def hatali_yakit_ekle(miktar: int, depo: list[int] = []) -> list[int]:
        depo.append(miktar)
        return depo

    ilk = hatali_yakit_ekle(10)
    ikinci = hatali_yakit_ekle(20)

    assert ilk is ikinci
    assert ikinci == [10, 20]


def test_none_pattern_creates_independent_lists() -> None:
    """None varsayılanı kullanıldığında her çağrı yeni bir liste alır."""
    def yakit_ekle(miktar: int, depo: list[int] | None = None) -> list[int]:
        if depo is None:
            depo = []
        depo.append(miktar)
        return depo

    ilk_depo = yakit_ekle(10)
    ikinci_depo = yakit_ekle(20)

    assert ilk_depo == [10]
    assert ikinci_depo == [20]
    assert ilk_depo is not ikinci_depo


def test_global_scope_read_and_local_assignment_trap() -> None:
    """Global değişkeni okumak mümkündür; aynı isimle atama yerel değişken hatası doğurur."""
    x = 7

    def sadece_oku() -> int:
        return x

    def oku_ve_artir() -> int:
        x = x + 1  # noqa: F823 - test edilen UnboundLocalError örneği
        return x

    assert sadece_oku() == 7
    try:
        oku_ve_artir()
    except UnboundLocalError:
        pass
    else:
        raise AssertionError("Yerel atama örneğinin UnboundLocalError vermesi bekleniyordu.")


def test_nested_function_changes_enclosing_value_with_nonlocal() -> None:
    """İç fonksiyon nonlocal ile dış fonksiyonun yerel değerini artırabilir."""
    def sayac_olustur() -> Callable[[], int]:
        deger = 0

        def artir() -> int:
            nonlocal deger
            deger += 1
            return deger

        return artir

    sayac = sayac_olustur()
    assert [sayac(), sayac(), sayac()] == [1, 2, 3]
