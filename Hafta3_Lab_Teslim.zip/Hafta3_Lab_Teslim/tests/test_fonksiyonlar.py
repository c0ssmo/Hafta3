"""Görev 1 ve 3 için davranış odaklı testler."""

import pytest

from uzay_oyunu.oyun import envanter_metni, galaksi_kur, hedef_menusu


def test_envanter_esyalari_virgulle_birlesir() -> None:
    assert envanter_metni(True, False, True) == "Sende: bol kredi, yetenekli bir pilot "


def test_bos_envanter_bos_metin_verir() -> None:
    assert envanter_metni(False, False, False) == ""


def test_hedefler_satir_satir_numaralanir() -> None:
    assert hedef_menusu(["centauri", "sirius"]) == (
        "Nereye gitmek istersin?\n[1] centauri\n[2] sirius"
    )


def test_galaksi_yakit_varsayilanini_kullanir() -> None:
    durum = galaksi_kur(["mars"], {"mars": []}, "mars")
    assert durum["yakit"] == 50
    assert durum["konum"] == "mars"


def test_galaksi_verilen_yakit_degerini_korur() -> None:
    durum = galaksi_kur(["dünya"], {"dünya": []}, "dünya", yakit=100)
    assert durum["yakit"] == 100


def test_listede_olmayan_baslangic_hata_verir() -> None:
    with pytest.raises(ValueError):
        galaksi_kur(["mars"], {"mars": []}, "dünya")
