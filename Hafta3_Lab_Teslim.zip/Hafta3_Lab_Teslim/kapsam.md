# Kapsam (Scope) örnekleri: tahmin ve gerçek sonuç

Bu dosyada her örnek için önce beklenen sonucu tahmin ettim, ardından Python davranışını kontrol edip nedenini açıkladım.

## 1. Fonksiyon içinden dış kapsam değişkenini okumak

```python
x = 7

def sadece_oku():
    return x

print(sadece_oku())
```

- **Tahmin:** `7` yazdırılır.
- **Gerçek sonuç:** `7`
- **Neden:** Fonksiyon içinde `x` adına atama yapılmadığı için Python adı dış kapsamda arar ve tanımlı değeri okuyabilir.

## 2. Yerel atama ve `UnboundLocalError`

```python
x = 7

def oku_ve_artir():
    x = x + 1
    return x

oku_ve_artir()
```

- **Tahmin:** Fonksiyon `x` değerini önce okumaya çalışırken hata verir.
- **Gerçek sonuç:** `UnboundLocalError: cannot access local variable 'x' where it is not associated with a value` (Python sürümüne göre hata mesajının ifadesi değişebilir).
- **Neden:** Fonksiyon gövdesinde `x` için atama bulunduğundan Python bu adı yerel kabul eder. Sağ taraftaki `x` okunurken yerel değişkene henüz değer verilmemiştir. Bu ödevde `global` kullanmak yasak olduğundan uygun çözümler, değeri parametre olarak geçirmek veya bir dış fonksiyon kapsamındaki değişkeni `nonlocal` ile yönetmektir.

## 3. İç içe fonksiyon ve `nonlocal`

```python
def sayac_olustur():
    deger = 0
    def artir():
        nonlocal deger
        deger += 1
        return deger
    return artir

sayac = sayac_olustur()
print(sayac())
print(sayac())
```

- **Tahmin:** Sırasıyla `1` ve `2` yazdırılır.
- **Gerçek sonuç:**

```text
1
2
```

- **Neden:** `artir` fonksiyonu `deger` değişkenini kendi yerel değişkeni olarak değil, onu çevreleyen `sayac_olustur` kapsamındaki değişken olarak ele alır. Closure, dış fonksiyon bitse bile bu değeri saklar; `nonlocal` değerin güncellenmesine izin verir.
