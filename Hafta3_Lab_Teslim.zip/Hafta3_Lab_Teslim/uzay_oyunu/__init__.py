"""Hafta 3 ileri Python laboratuvarı: modüler uzay oyunu."""
