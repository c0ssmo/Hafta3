"""Uzay oyununun metin arayüzü ve galaksi kurulum işlevleri."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .araclar import hamle_sayaci


def envanter_metni(credits: bool, engines: bool, copilot: bool) -> str:
    """Sahip olunan öğeleri tek satırlık bir metin olarak verir; envanter boşsa boş döner."""
    esyalar: list[str] = []
    if credits:
        esyalar.append("bol kredi")
    if engines:
        esyalar.append("hiperdrive")
    if copilot:
        esyalar.append("yetenekli bir pilot")
    return f"Sende: {', '.join(esyalar)} " if esyalar else ""


def hedef_menusu(hedefler: list[str]) -> str:
    """Verilen hedefleri sıralı ve numaralı bir menü biçiminde biçimlendirir."""
    satirlar = ["Nereye gitmek istersin?"]
    satirlar.extend(f"[{sira}] {hedef}" for sira, hedef in enumerate(hedefler, start=1))
    return "\n".join(satirlar)


def galaksi_kur(
    gezegenler: list[str],
    baglantilar: dict[str, list[str]],
    baslangic: str,
    **kwargs: Any,
) -> dict[str, Any]:
    """Galaksi durumunu hazırlar; geçersiz başlangıç için ValueError yükseltir."""
    if baslangic not in gezegenler:
        raise ValueError(f"Başlangıç gezegeni '{baslangic}' gezegen listesinde bulunamadı.")
    return {
        "gezegenler": gezegenler,
        "baglantilar": baglantilar,
        "konum": baslangic,
        "yakit": kwargs.get("yakit", 50),
    }


def galaksi_dosyadan_oku(dosya: str | Path | None = None) -> dict[str, Any]:
    """JSON haritasını yükler ve galaksi_kur ile oyun durumuna dönüştürür."""
    kaynak = Path(dosya) if dosya is not None else Path(__file__).with_name("galaksi.json")
    with kaynak.open("r", encoding="utf-8") as dosya_objesi:
        veri = json.load(dosya_objesi)
    return galaksi_kur(**veri)


def travel(galaksi: dict[str, Any] | None = None) -> None:
    """Oyuncuyu bağlantılı gezegenler arasında yönlendirerek kara deliğe ulaştırır."""
    durum = galaksi if galaksi is not None else galaksi_dosyadan_oku()
    sayac = hamle_sayaci()
    hamle_toplami = 0

    while durum["konum"] != "kara_delik":
        mevcut = durum["konum"]
        hedefler = durum["baglantilar"].get(mevcut, [])
        print(f"\nŞu an bulunduğun yer: {mevcut.upper()}")
        print(envanter_metni(True, False, True))
        print(hedef_menusu(hedefler))
        secim = input("Hedef numarasını gir (çıkmak için q): ").strip()

        if secim.lower() == "q":
            print("Yolculuk sonlandırıldı.")
            break
        if not secim.isdigit() or not 1 <= int(secim) <= len(hedefler):
            print("Geçersiz seçim. Menüdeki numaralardan birini yaz.")
            continue

        durum["konum"] = hedefler[int(secim) - 1]
        hamle_toplami = sayac()

    if durum["konum"] == "kara_delik":
        print(f"Oyunu {hamle_toplami} hamlede bitirdin!")
    else:
        print(f"Yolculuk {hamle_toplami} hamleden sonra durdu.")


if __name__ == "__main__":
    travel()
