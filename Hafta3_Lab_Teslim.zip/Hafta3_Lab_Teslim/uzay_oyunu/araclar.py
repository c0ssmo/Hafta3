"""Sayaç, sıralama ve çalışma süresi ölçümü gibi yardımcı işlevler."""

from __future__ import annotations

from functools import wraps
from time import perf_counter
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def hamle_sayaci() -> Callable[[], int]:
    """Her çağrıda bir artan sayaç fonksiyonu üretir (closure ve nonlocal)."""
    toplam = 0

    def sonraki_hamle() -> int:
        nonlocal toplam
        toplam += 1
        return toplam

    return sonraki_hamle


def en_bagli_gezegenler(galaksi: dict[str, Any]) -> list[str]:
    """Gezegenleri bağlantı sayısına göre azalan, eşitlikte alfabetik sıralar."""
    gezegenler = galaksi["gezegenler"]
    baglantilar = galaksi["baglantilar"]
    return sorted(gezegenler, key=lambda gezegen: (-len(baglantilar[gezegen]), gezegen))


def sure_olc(fonksiyon: F) -> F:
    """Fonksiyon çağrısını sarmalar, geçen süreyi saniye olarak yazdırır ve sonucu korur."""
    @wraps(fonksiyon)
    def sarmalayici(*args: Any, **kwargs: Any) -> Any:
        baslangic = perf_counter()
        try:
            return fonksiyon(*args, **kwargs)
        finally:
            gecen = perf_counter() - baslangic
            print(f"{fonksiyon.__name__} çalışma süresi: {gecen:.6f} saniye")

    return sarmalayici  # type: ignore[return-value]


if __name__ == "__main__":
    from .oyun import galaksi_dosyadan_oku

    siralama = sure_olc(en_bagli_gezegenler)
    print(siralama(galaksi_dosyadan_oku()))
