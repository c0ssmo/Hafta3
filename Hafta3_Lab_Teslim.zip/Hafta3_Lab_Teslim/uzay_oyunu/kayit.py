"""Görev adımlarını esnek parametrelerle kaydetme araçları."""


def gorev_kaydi(baslik: str, *adimlar: str, oncelik: str = "normal", **ekler: str) -> None:
    """Başlığı, sıralı adımları ve ek alanları konsola düzenli biçimde yazar."""
    print(f"[{oncelik.upper()}] {baslik}")
    for sira, adim in enumerate(adimlar, start=1):
        print(f"  {sira}. {adim}")
    for alan, deger in ekler.items():
        print(f"  {alan}: {deger}")


if __name__ == "__main__":
    # Doğrudan argümanlarla çağrı
    gorev_kaydi(
        "Kara deliğe ulaş",
        "Kredi topla",
        "Bir pilot bul",
        "Hiperdrive edin",
        oncelik="yüksek",
        sorumlu="Ayşe",
    )

    print("-" * 24)

    # Liste ve sözlük içeriğini çağrı sırasında açma
    adimlar = ["Yakıtı kontrol et", "Rotayı seç", "Kara deliğe ilerle"]
    bilgiler = {"sorumlu": "Ayşe"}
    gorev_kaydi("Son yolculuk", *adimlar, oncelik="yüksek", **bilgiler)
